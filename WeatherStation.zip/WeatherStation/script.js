function fetchWeather() {
    const API_KEY = "d8141703bbdf421fb0825733242604";
    const selectedCity = document.getElementById("city-select").value;
    const API_URL = `http://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${selectedCity}`;

    fetch(API_URL)
        .then(response => response.json())
        .then(data => {
            const temperature = data.current.temp_c;
            const humidity = data.current.humidity;
            const pressure = data.current.pressure_mb;

            const weatherInfo = document.querySelector('.weather-info');
            weatherInfo.innerHTML = `
                <p>Temperature: ${temperature} °C</p>
                <p>Humidity: ${humidity} %</p>
                <p>Pressure: ${pressure} hPa</p>
            `;
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            const weatherInfo = document.querySelector('.weather-info');
            weatherInfo.innerHTML = `<p>Error fetching weather data.</p>`;
        });
}

document.addEventListener('DOMContentLoaded', fetchWeather);
